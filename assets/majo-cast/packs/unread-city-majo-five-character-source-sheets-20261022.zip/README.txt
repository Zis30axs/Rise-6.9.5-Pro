Unread City / Majo cast: 5 ORIGINAL JPG character contact sheets.
3 columns per sheet: neutral, happy, thinking (candidate labels only).
Manifest maps images to content-addressed assets/<sha256>.
No nine-expression completion claim. Binary source images kept unchanged.
This ZIP is a local static asset handoff, not a full Lite resource pack.
To use, import/commit the archive contents on PR #16 asset branch.
